
from setuptools import setup, find_packages

setup(
    name='youtube_wrapper',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'google-api-python-client',
    ],
    description='A package to interact with YouTube Data API',
    author='Harshitha_2003.B',
    author_email='praniharshitha@gmail.com',
    url='https://your-url.com',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)

setup(
    name="youtube_transcript_api_wrapper",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "youtube-transcript-api"
    ],
    description="A wrapper module for YouTube Transcript API.",
    author='Harshitha_2003.B',
    author_email='praniharshitha@gmail.com',
    url="https://github.com/yourusername/youtube_transcript_api_wrapper",
)

